\
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

void main() {
  runApp(MyApp());
}

const String API_KEY = String.fromEnvironment('API_KEY', defaultValue: 'YOUR_API_KEY_HERE');
const Duration AUTO_REFRESH = Duration(seconds: 60);

final List<LeagueConfig> leaguePriority = [
  LeagueConfig(name: 'الدوري الإنجليزي', id: 39),
  LeagueConfig(name: 'الدوري الإسباني', id: 140),
  LeagueConfig(name: 'الدوري الإيطالي', id: 135),
  LeagueConfig(name: 'الدوري الألماني', id: 78),
  LeagueConfig(name: 'الدوري الفرنسي', id: 61),
];

class LeagueConfig {
  final String name;
  final int id;
  LeagueConfig({required this.name, required this.id});
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'مواعيد ونتائج المباريات',
      theme: ThemeData(primarySwatch: Colors.green, fontFamily: 'Arial'),
      home: HomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MatchItem {
  final int fixtureId;
  final String home;
  final String away;
  final String homeLogo;
  final String awayLogo;
  final String statusShort;
  final String minute;
  final String homeScore;
  final String awayScore;
  final DateTime kickoff;
  final int leagueId;

  MatchItem({
    required this.fixtureId,
    required this.home,
    required this.away,
    required this.homeLogo,
    required this.awayLogo,
    required this.statusShort,
    required this.minute,
    required this.homeScore,
    required this.awayScore,
    required this.kickoff,
    required this.leagueId,
  });
}

enum FilterTab { upcoming, live, finished }

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with SingleTickerProviderStateMixin {
  Map<int, List<MatchItem>> leagueMatches = {};
  bool loading = true;
  Timer? _timer;
  DateTime lastUpdated = DateTime.now();
  FilterTab activeTab = FilterTab.upcoming;
  TabController? _tabController;

  @override
  void initState() {
    super.initState();
    _fetchAll();
    _timer = Timer.periodic(AUTO_REFRESH, (_) => _fetchAll());
    _tabController = TabController(length: 3, vsync: this);
    _tabController!.addListener(() {
      setState(() {
        activeTab = FilterTab.values[_tabController!.index];
      });
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _tabController?.dispose();
    super.dispose();
  }

  Future<void> _fetchAll() async {
    setState(() {
      loading = true;
    });
    final today = DateFormat('yyyy-MM-dd').format(DateTime.now().toUtc());
    Map<int, List<MatchItem>> result = {};

    for (final league in leaguePriority) {
      try {
        final matches = await fetchMatchesForLeague(league.id, today);
        result[league.id] = matches;
      } catch (e) {
        result[league.id] = [];
        print('خطأ عند جلب الدوري ${league.name}: $e');
      }
    }

    setState(() {
      leagueMatches = result;
      loading = false;
      lastUpdated = DateTime.now();
    });
  }

  Future<List<MatchItem>> fetchMatchesForLeague(int leagueId, String date) async {
    final uri = Uri.https('v3.football.api-sports.io', '/fixtures', {
      'league': leagueId.toString(),
      'date': date,
      'timezone': 'UTC',
    });
    final resp = await http.get(uri, headers: {
      'x-apisports-key': API_KEY,
    });

    if (resp.statusCode != 200) {
      throw Exception('API error: ${resp.statusCode}');
    }

    final data = jsonDecode(resp.body);
    final List fixtures = data['response'] ?? [];

    return fixtures.map<MatchItem>((f) {
      final fixture = f['fixture'];
      final teams = f['teams'];
      final goals = f['goals'];
      final status = f['fixture']['status'];
      // logos may be in teams['home']['logo'] or teams['home']['image']
      final homeLogo = teams['home']?['logo'] ?? teams['home']?['image'] ?? '';
      final awayLogo = teams['away']?['logo'] ?? teams['away']?['image'] ?? '';
      return MatchItem(
        fixtureId: fixture['id'],
        home: teams['home']['name'] ?? '',
        away: teams['away']['name'] ?? '',
        homeLogo: homeLogo ?? '',
        awayLogo: awayLogo ?? '',
        statusShort: status['short'] ?? '',
        minute: status['elapsed']?.toString() ?? '',
        homeScore: (goals['home'] == null) ? '-' : goals['home'].toString(),
        awayScore: (goals['away'] == null) ? '-' : goals['away'].toString(),
        kickoff: DateTime.parse(fixture['date']).toLocal(),
        leagueId: leagueId,
      );
    }).toList();
  }

  List<MatchItem> _filterMatches(List<MatchItem> list) {
    switch (activeTab) {
      case FilterTab.upcoming:
        return list.where((m) => m.statusShort == 'NS' || m.statusShort.isEmpty).toList();
      case FilterTab.live:
        return list.where((m) => !(m.statusShort == 'NS' || m.statusShort == 'FT' || m.statusShort == '')).toList();
      case FilterTab.finished:
        return list.where((m) => m.statusShort == 'FT' || m.statusShort == 'AET' || m.statusShort == 'PEN').toList();
    }
  }

  Widget _buildMatchTile(MatchItem m) {
    String subtitle;
    if (m.statusShort == 'NS' || m.statusShort.isEmpty) {
      subtitle = DateFormat('HH:mm').format(m.kickoff) + ' – لم تبدأ';
    } else if (m.statusShort == 'FT' || m.statusShort == 'AET' || m.statusShort == 'PEN') {
      subtitle = 'انتهت';
    } else {
      final minuteText = m.minute.isNotEmpty ? '${m.minute}′' : '';
      subtitle = 'جارية $minuteText';
    }

    final scoreText = (m.homeScore == '-' && m.awayScore == '-') ? '' : '${m.homeScore} - ${m.awayScore}';

    return Card(
      child: ListTile(
        leading: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (m.homeLogo.isNotEmpty)
              SizedBox(
                width: 36,
                height: 36,
                child: Image.network(m.homeLogo, fit: BoxFit.contain, errorBuilder: (_,__,___)=>SizedBox()),
              )
            else
              SizedBox(width:36,height:36),
            SizedBox(height:4),
            if (m.awayLogo.isNotEmpty)
              SizedBox(
                width: 36,
                height: 36,
                child: Image.network(m.awayLogo, fit: BoxFit.contain, errorBuilder: (_,__,___)=>SizedBox()),
              )
            else
              SizedBox(width:36,height:36),
          ],
        ),
        title: Text('${m.home}  vs  ${m.away}', textAlign: TextAlign.right),
        subtitle: Text(subtitle, textAlign: TextAlign.right),
        trailing: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(scoreText, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            SizedBox(height: 6),
            Text(m.statusShort, style: TextStyle(fontSize: 12)),
          ],
        ),
        isThreeLine: true,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text('مواعيد ونتائج المباريات'),
          centerTitle: true,
          actions: [
            IconButton(onPressed: _fetchAll, icon: Icon(Icons.refresh)),
          ],
          bottom: TabBar(
            controller: _tabController,
            tabs: [
              Tab(text: 'القادمة'),
              Tab(text: 'الجارية'),
              Tab(text: 'المنتهية'),
            ],
          ),
        ),
        body: loading
            ? Center(child: CircularProgressIndicator())
            : RefreshIndicator(
                onRefresh: _fetchAll,
                child: ListView.builder(
                  padding: EdgeInsets.all(8),
                  itemCount: leaguePriority.length + 1,
                  itemBuilder: (ctx, idx) {
                    if (idx == 0) {
                      return Padding(
                        padding: EdgeInsets.symmetric(vertical: 8),
                        child: Text(
                          'محدّث: ${DateFormat('yyyy-MM-dd HH:mm:ss').format(lastUpdated)} — يتحدّث تلقائيًا كل ${AUTO_REFRESH.inSeconds} ثانية',
                          textAlign: TextAlign.center,
                        ),
                      );
                    }
                    final league = leaguePriority[idx - 1];
                    final matches = leagueMatches[league.id] ?? [];
                    final filtered = _filterMatches(matches);
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        SizedBox(height: 6),
                        Text(league.name, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                        SizedBox(height: 6),
                        filtered.isEmpty
                            ? Padding(
                                padding: EdgeInsets.symmetric(vertical: 8),
                                child: Text('لا توجد مباريات في هذا القسم اليوم.'),
                              )
                            : Column(
                                children: filtered.map((m) => _buildMatchTile(m)).toList(),
                              ),
                        Divider(height: 20),
                      ],
                    );
                  },
                ),
              ),
      ),
    );
  }
}
